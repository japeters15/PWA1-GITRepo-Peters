/*
 Janay Peters
 8/7/15
 Goal1: Assignment Duel1
 */

/*PseudoCode
1. Remove all alerts
2. Create three property keys for both fighters
3. Modify fight function (No Loops, replace alerts with DOM, and use innerHTML to change text
4. Create a Click event
5. Make the round advance and call fight()
6. Make sure game over message shows at top (Fighter 1 wins, Fighter 2 wins, or both fighters die)


 */
// self-executing function
(function(){

    console.log("FIGHT!!");

    //player name, damage, health
    var fighter1 = {name:Spiderman, damage:20, health:100;
    var fighter2 = {name:Batman, damage:20, health:100;

    var round = 0;

    function fight(){

        var fight = document.getElementById("scores");

        fight.innerHTML = "Fight"

        for(var i=0;i<10; i++){

            //ramdom formula is - Math.floor(Math.random()*(max-min)+min);

            var minDamage1 = fighter1[20] * 0.5;
            var minDamage2 = fighter2[20] * 0.5;
            var f1 = Math.floor(Math.random()*(fighter1[20]-minDamage1)+minDamage1);
            var f2 = Math.floor(Math.random()*(fighter2[20]-minDamage2)+minDamage2);

            //inflict damage
            fighter1[100]-=f1;
            fighter2[100]-=f2;

            console.log(fighter1[spiderman]+":"+player2[100]+""+fighter2[batman]+":"+fighter2[100]);

            var results = winnerCheck();
            console.log(results);

            if(results === "no winner"){
                round++;
                alert(fighter1[spiderman]+":"+fighter1[100]+"ROUND"+round+"OVER"+fighter2[batman]+":"+fighter2[100]);

            }else{
                alert(results);
                break;
            }


        }
    }

    function winnerCheck(){
        console.log("in winnerCheck FN");

        var result="no winner";

        if(fighter1[100]<1&&fighter2[100]<1) {
            result = "you both die";
        } else if(fighter1[100]<1){
            result = fighter2[batman]+"WINS!!!";
        } else if(fighter2[100]<1){
            result = playerOne[0]+"WINS!!!";
        }

        return result;
    }

    /*******The program begins******/
    console.log('program starts');
    fight();

})();

